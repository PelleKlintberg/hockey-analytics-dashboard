# Hockey Analytics Dashboard

Detta är Streamlit-appen för hockeyanalys.

## Starta appen lokalt

1. Packa upp zip-filen.
2. Öppna PowerShell/Terminal i mappen.
3. Kör:

```powershell
pip install -r requirements.txt
streamlit run app.py
```

4. Öppna länken som visas i terminalen, oftast:

```text
http://localhost:8501
```

## Enkel Windows-start

Dubbelklicka på:

```text
start_app_windows.bat
```

för att installera kraven och starta appen.

## Dela med andra tränare

Skicka hela zip-filen till mottagaren. De behöver Python installerat.

## Version

Bygger på appversion V4.13:
- taxonomy som grundstruktur
- alla metrics kvar
- checkbox-lista med full metrictext
- uppladdad data fyller värden
- saknade metrics visas men ritas inte förrän datan finns
