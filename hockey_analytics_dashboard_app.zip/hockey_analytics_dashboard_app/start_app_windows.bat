@echo off
echo Installing requirements...
pip install -r requirements.txt
echo.
echo Starting Hockey Analytics Dashboard...
streamlit run app.py
pause
